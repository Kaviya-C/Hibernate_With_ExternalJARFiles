package com.model.hibernate;

public class Customer {
	
	private int custId;
	private String custName;
	private String custEmail;

	public void setCustId(int custId)
	{
		this.custId=custId;
	}
	public int getCustId()
	{
		return custId;
	}
	public void setCustName(String custName)
	{
		this.custName=custName;
	}
	public String getCustName()
	{
		return custName;
	}
	public void setCustEmail(String custEmail)
	{
		this.custEmail=custEmail;
	}
	public String getCustEmail()
	{
		return custEmail;
	}
}
