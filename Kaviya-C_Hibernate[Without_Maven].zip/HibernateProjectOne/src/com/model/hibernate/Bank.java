package com.model.hibernate;

public class Bank {
	private int bankId;
	private String bankName;
	private String bankAddress;
	
	
	public void setBankId(int bankId)
	{
		this.bankId=bankId;
	}
	public int getBankId()
	{
		return bankId;
	}
	public void setBankName(String bankName)
	{
		this.bankName=bankName;
	}
	public String getBankName()
	{
		return bankName;
	}
	public void setBankAddress(String bankAddress)
	{
		this.bankAddress=bankAddress;
	}
	public String getBankAddress()
	{
		return bankAddress;
	}

}
